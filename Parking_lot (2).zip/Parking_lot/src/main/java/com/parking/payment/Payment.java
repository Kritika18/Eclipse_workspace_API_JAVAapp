package com.parking.payment;

public interface Payment  {

	void vehicle();
	void rate(int n);
	
}
