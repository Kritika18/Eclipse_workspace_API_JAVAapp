package registerapi.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import registerapi.Model.UserRegDTO;
import registerapi.Service.UserserviceImpl;

@RestController
public class registercontroller {
	
	
	@RequestMapping("/Hi")
	public String Hi()
	{
	   return "Welcome";	
	}
	@Autowired
	UserserviceImpl userSer;
	@PostMapping("/register")  
	private int save(@RequestBody UserRegDTO u)   
	{  
	userSer.saveOrUpdate(u);  
	return u.getId();  
	}  
}
