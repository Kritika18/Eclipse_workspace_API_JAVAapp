package registerapi.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import registerapi.Model.UserRegDTO;
import registerapi.dao.Userdaoimpl;

@Service
public class UserserviceImpl  {
	
	@Autowired
	Userdaoimpl repo;
	
//	public void register(UserRegDTO user)
//	{
//		return repo.registerUser(user) > 0 ? true : false ;
//		
//	}
	
	public void saveOrUpdate(UserRegDTO user)   
	{  
	  repo.registerUser(user);  
	}  

}
