package registerapi.dao;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import registerapi.Model.UserRegDTO;

@Repository
public class Userdaoimpl {

	@Autowired
    private JdbcTemplate jdbc;

	
	
	public void registerUser(UserRegDTO u) {
		// TODO Auto-generated method stub
		
		String sql = "insert into users(id , firstname , lastname , email ,mobile ) values(?,?,?,?,?)";
		try {
			jdbc.update(sql , u.getId(), u.getFirstName() , u.getLastname(),u.getEmail(),u.getMobile() );
		}
		catch(Exception e) {
			
			System.out.println(e);
		
		
		}	
	}
	
	
	

}
