package parking_lot.payment;

public class Car implements Payment {

	public void vehicle() {
		System.out.print("car");
		
	}

	public void rate(int n ) {
		int rate , no;
		if(n<=2)
		{
			rate =20;   // i have declared common charge for <2 hour 
			System.out.println("Pay" + rate);
		}
		else
		{
			 no = n-2;
			 rate = (20 + 10* no);
			 System.out.println("Pay" + rate);
		}
		
	} 
		
		
		
	
	public void rateabove() {
		
		System.out.print("+10 Rs");
		
	}
	
	public void discount() {
		
		
	System.out.print("Monday free ");

		
	}
	
}
