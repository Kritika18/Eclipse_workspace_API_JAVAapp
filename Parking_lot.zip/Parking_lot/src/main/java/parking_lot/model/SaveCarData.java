package parking_lot.model;

import java.util.Scanner;

import parking_lot.CreateParking;

public class SaveCarData extends CreateParking {
	
	private Integer plateNo;
	private String color;
	private Integer time;
	private Integer spot;
	private String vehicle;
	
	
	public String getVehicle() {
		return vehicle;
	}

	public void setVehicle(String vehicle) {
		this.vehicle = vehicle;
	}

	public Integer getPlateNo() {
		return plateNo;
	}
	
	public Integer setPlateNo(Integer plateNo) {
		return this.plateNo = plateNo;
	}
	
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public Integer getTime() {
		return time;
	}
	public void setTime(Integer time) {
		this.time = time;
	}
	
	public Integer setSpot(Integer spot) {
		return this.spot = set(plateNo);
	}
	
	
	public Integer getSpot(Integer plateNo) {
		
	  	
	  return spot ;
	}
	
	
	
	
	
    

}
